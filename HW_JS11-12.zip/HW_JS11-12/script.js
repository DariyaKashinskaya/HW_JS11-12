const buttonSignUp = document.querySelector('.button-sign-up') 
const buttonLogIn = document.querySelector('.button-log-in')
const buttonmainP = document.querySelectorAll('.button-mainP')

const logIn = document.querySelector('.log-in')  
const signUp = document.querySelector('.sign-up')
const mainP = document.querySelector('.mainP')

const adresReg = document.querySelector('.adres-reg') 
const passwordReg = document.querySelector('.passw-reg')
const passwordRegRep = document.querySelector('.passwreg')
const adresLog = document.querySelector('.adress-log-in')
const passwordLog = document.querySelector('.passlog')

const sendReg = document.querySelector('.sendreg')
const sendLogIn = document.querySelector('.sendlog')

let wrongInput = document.createElement('p')   
wrongInput.style.color = 'red'
wrongInput.classList.add('wrongimp')
let insertWrong = function(cont, button, wrong) { 
    wrongInput.innerHTML = wrong 
    if (!(cont.contains(document.querySelector('.wrongimp')))) {
        button.insertAdjacentElement('beforebegin', wrongInput)
    }
}
let deleteWrong = function(cont, button) { 
    if (cont.contains(document.querySelector('.wrongimp'))) { 
        button.previousElementSibling.remove()
    }
}

let arrFormRegistration = []
const Site = function() {
    const self = this
    this.showmainP = function() {
        mainP.style.display = 'block'
        signUp.style.display = 'none'
        logIn.style.display = 'none'
        buttonLogIn.addEventListener('click', self.showAuthPage)
        buttonSignUp.addEventListener('click', self.showRegistrationPage)
    }
    this.showRegistrationPage = function() {
        mainP.style.display = 'none'
        signUp.style.display = 'block'
        logIn.style.display = 'none'
        buttonmainP[1].addEventListener('click', self.showmainP)
        sendReg.addEventListener('click', self.registration)

        adresReg.addEventListener('keydown', (event) => {   
            if (event.key === 'Enter') self.registration()
        })
        passwordReg.addEventListener('keydown', (event) => {   
            if (event.key === 'Enter') self.registration()
        })
        passwordRegRep.addEventListener('keydown', (event) => {   
            if (event.key === 'Enter') self.registration()
        })
        document.querySelector('.linkLog').addEventListener('click', self.showAuthPage) 
    }
    this.showAuthPage = function() {
        mainP.style.display = 'none'
        signUp.style.display = 'none'
        logIn.style.display = 'block'
        buttonmainP[0].addEventListener('click', self.showmainP)
        sendLogIn.addEventListener('click', self.login)
        adresLog.addEventListener('keydown', (event) => {          
            if (event.key === 'Enter') self.login()
        })
        passwordLog.addEventListener('keydown', (event) => {          
            if (event.key === 'Enter') self.login()
        })
        document.querySelector('.link-to-sign-up').addEventListener('click', self.showRegistrationPage) 
    }
    this.registration = function() {
        const user = {email: adresReg.value, password: passwordReg.value, repeatPassword: passwordRegRep.value}

        if (passwordReg.value !== passwordRegRep.value) {  
            insertWrong(signUp, sendReg, 'Второй пароль не совпадает с первым')
        } else {
            if ((adresReg.value === '') || (passwordReg.value === '') || (passwordRegRep.value === '')) {      
                insertWrong(signUp, sendReg, 'Заполните все поля')
            } else {
                if (passwordReg.value.split('').length < 7) {   
                    insertWrong(signUp, sendReg, 'Минимум 7 символов')
                } else {
                    if (!(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/g.test(adresReg.value))) { 
                    insertWrong(signUp, sendReg, 'Неверный адрес электронной почты')
                    } else {
                        deleteWrong(signUp, sendReg)
                        arrFormRegistration.push(user)
                        alert('Сохранено')
                    }
                }
            }
        }
        console.log(arrFormRegistration);
    }
    this.login = function() {
        if (adresLog.value === '') {      
            insertWrong(logIn, sendLogIn, 'Заполните все поля')
        } else {
            const user = arrFormRegistration.find(currentUser => currentUser.email === adresLog.value)  
            if (user === undefined) {       
            insertWrong(logIn, sendLogIn, 'Неверный адрес электронной почты')
            } else {
                if (user.password !== passwordLog.value) {
                    insertWrong(logIn, sendLogIn, 'Неверный пароль')
                } else {            
                    deleteWrong(logIn, sendLogIn)
                    alert('Вы авторизованы')
                }
            } 
        }
    }
}

const site = new Site()
site.showmainP()

